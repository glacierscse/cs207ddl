NUM_TS = 1000

NUM_VP = 20

# parameters for generating timeseries data
mean_start, mean_end = -100, 100
std_start, std_end = 0.1, 10
scale_start, scale_end = 1, 10
