rm -r timeseriesDB 
rm -r ts_db_index
rm id.json
rm -r ts_data
rm API/app.db
python setup_DB.py
